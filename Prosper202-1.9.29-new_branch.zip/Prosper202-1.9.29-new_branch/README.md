# Prosper202-1.9.29
Self-hosted CPA Tracking Software

This is the last free version of [Prosper202](http://prosper.tracking202.com/apps/), released under [Attribution-NonCommercial-ShareAlike 3.0 Unported license](https://creativecommons.org/licenses/by-nc-sa/3.0/). If you like this software, please consider upgrading to paid version.

I've made few changes.

* Removed Redirect to auto-upgrade page
* Removed most of advertising
* Added links to tutorials

[Prosper202 Installation service is offered here](https://vpsfix.com/product/install-prosper202-service/)
