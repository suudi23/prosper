<?php 

class CACHE
{

}
